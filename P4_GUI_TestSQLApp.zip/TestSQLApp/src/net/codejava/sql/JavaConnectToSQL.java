/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package net.codejava.sql;


import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;



/**
 *
 * @author chaitanya
 */
public class JavaConnectToSQL {
     
    public static void main(String[] args)
    {   
              String serverName = "localhost";
              String dbName = "App_Store_Management";
              String url = "jdbc:sqlserver://" +serverName + ":1433;DatabaseName=" + dbName + ";encrypt=true;trustServerCertificate=true";
              String username = "SA";
              String password = "Orbiculos@63";
              
             
              
        try {
            Connection connection = DriverManager.getConnection(url,username,password);
            String sql = "Select * from APP";
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            while (rs.next()) {
              String AppName = rs.getString("App_Catagory");
              System.out.println(AppName + "\n");
            }

        } catch (SQLException ex) {
            System.out.println("ERROR");
            ex.printStackTrace();
        }
             
        
        
    }
    
}
